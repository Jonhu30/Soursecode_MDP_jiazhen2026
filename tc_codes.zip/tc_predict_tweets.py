import argparse, csv
import pandas as pd
import torch
from transformers import pipeline
import json

# 读取 JSON 文件的函数
def read_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return [json.loads(line.strip()) for line in f if line.strip()]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="Input JSON file")
    ap.add_argument("--text_col", default="headline", help="JSON key for text column (default: headline)")
    ap.add_argument("--output", default="predictions.csv")
    ap.add_argument("--batch_size", type=int, default=32)
    ap.add_argument("--top_k", type=int, default=3)
    ap.add_argument("--threshold", type=float, default=0.90)
    args = ap.parse_args()

    # 检查 GPU 是否可用
    device = 0 if torch.cuda.is_available() else -1

    clf = pipeline(
        "text-classification",
        model="/gpfs/work/aac/jiazhenhu24/PythonProjects/hf_cache/hub/models--classla--multilingual-IPTC-news-topic-classifier/snapshots/4d69cc69bbad47e815337ff70889c1d246b43cff",  # 使用本地缓存的模型
        device=device,
        truncation=True,
        max_length=512,
    )

    # 读取 JSON 数据
    data = read_json(args.input)
    texts = [item[args.text_col] for item in data]  # 提取 headline 字段
    ids = [item.get('article_link', f"unknown_{i}") for i, item in enumerate(data)]  # 使用 article_link 作为 ID

    with open(args.output, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["id", "headline", "label", "score", "topk_labels", "topk_scores", "note"])

        # 批量处理
        for i in range(0, len(texts), args.batch_size):
            batch_texts = texts[i:i+args.batch_size]
            batch_ids = ids[i:i+args.batch_size]

            preds = clf(batch_texts, top_k=args.top_k)

            for _id, text, p in zip(batch_ids, batch_texts, preds):
                if isinstance(p, dict):
                    p = [p]
                best = p[0]
                labels = [x["label"] for x in p]
                scores = [x["score"] for x in p]
                note = "" if best["score"] >= args.threshold else "uncertain(<threshold)"
                w.writerow([_id, text, best["label"], best["score"], "|".join(labels), "|".join(map(str, scores)), note])

    print(f"saved predictions to {args.output}")

if __name__ == "__main__":
    main()
